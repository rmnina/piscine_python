def count_in_list(lst: list, value: str) -> int:
    return lst.count(value)